# Student portal phase

New students can now apply through **`student.php?page=admissions`** after using the main homepage sign-in. Staff approval creates the enrolled-student account and admission letter. See [Online admissions](ONLINE-ADMISSIONS.md); applicant and student access use the same secure public session.

## Upgrade an already-installed CRM (do not reinstall)

1. Export the MySQL/MariaDB database in phpMyAdmin. Privately back up `config.php`, `storage/`, and the working application files. Test that the backup is usable.
2. Stop normal use/notification workers temporarily. Extract the updated ZIP into a **separate temporary folder**.
3. Merge/replace its `app/`, `public/`, `bin/`, `docs/`, `vendor/`, `composer.json` and help files into the existing project. **Keep your existing config.php, storage contents, database and installer locks. Never delete the existing project folder or rerun setup.php.** Do not nest an extra institute-crm folder.
4. Restart Apache (clears cached PHP). Sign in as the **group owner** at your usual `office.php`.
5. Open `upgrade.php`, confirm the backup and run the additive upgrade. It adds `portal_accounts`, `portal_otp_challenges`, `portal_events`, and the latest operations tables (see [Operations](OPERATIONS.md)); existing CRM tables/data remain in place. Re-running is safe. A database account with schema-creation/index permissions is needed during upgrade. Native MySQL DDL is not fully transactional; if it fails part-way, fix permissions and rerun rather than deleting data.
6. Alternatively, a server operator can run `php bin/migrate.php`. Fresh installations automatically include the new tables.
7. Test portal access with an email inbox you control, then resume normal work and the existing notification worker.

The owner can also find the upgrade link in **Account settings**. Non-owners and anonymous visitors cannot run the browser migration; it requires the normal owner session, CSRF token, and backup acknowledgement.

## Student self-registration (new)

Students can now create their own account before admission:

1. Open `index.php?page=login&show=create` (the **Create Student Account** button on the master sign-in page).
2. Enter full name, personal email and phone, then verify the six-digit email code (five-minute expiry, same-browser, 60-second resend cooldown).
3. The verified account shows an application checklist: apply for admission, track the latest application status, and — once the office admits them and enables portal access — refresh into the full student portal automatically.

Staff manage these accounts in **Student accounts** (owner/admin): verified name/email/phone, portal-link status (Linked/Not admitted) and enable/disable. Disabling signs the user out immediately; it does not change portal access. Registration never grants admission, fees or documents by itself — office approval is still required.

## Enable students

- Open **Students** as owner or institute admin.
- Check the correct **personal student email**, using Manage email / letter to fix it if needed. Verify the address with the student before granting access; an email typo can give another mailbox owner access to that student's documents.
- Click **Enable student access**. Counsellors cannot grant or revoke portal access. Institute admins can only manage their own institute's students.
- Share `https://your-institute-domain/index.php?page=login`, or the corresponding `/institute-crm/index.php?page=login` subdirectory URL under XAMPP.
- On the XAMPP computer: `http://localhost/institute-crm/index.php?page=login`. That localhost URL is **not** reachable by students on their own devices. Deploy to a secured live server before providing remote access.

Enabling does **not** send an invitation email automatically. Students are not automatically enabled when admitted. Every account must be explicitly enabled by authorized staff.

## Student experience

1. Open the separate student sign-in page (also linked from staff login).
2. Enter the email registered on their enabled portal account.
3. PHPMailer sends a six-digit code using the existing server SMTP settings. Enter it within five minutes in the same browser. The code can be used once; five attempts are allowed. Resends have a 60-second cooldown and additional IP/email throttles.
4. View:
   - **Overview:** admission/course summary, agreed fee, recorded payments, current remaining balance, available-document count, institute contact.
   - **My payments:** paginated payment history with receipt numbers, dates, methods/references, amounts and receipt downloads.
   - **My documents:** only that student's existing admission letters/payment receipts.
   - **My profile:** read-only registered contact and academic admission details; corrections go through the institute office.
5. Sign out; sessions also expire after 30 minutes of inactivity.

Official academic/financial records are **read-only**. The new Support section permits students to open private tickets and reply to their own conversations. It is not an online payment gateway. It exposes no enquiry notes, staff directory, other student data, finance-management actions or raw email-queue data. Academic record now shows published daily attendance and batch history after the operations upgrade. My results now shows published individual assessments; Announcements shows currently eligible notices. See [Student services](STUDENT-SERVICES.md). The balance is admission fee minus recorded payments; My payments additionally shows an installment schedule when staff has created one. Existing receipts show their saved payment-time snapshot, not necessarily today's balance.

Missing admission letters can be generated by staff using **Students → Manage email / letter → Create admission letter**. No student-triggered PDF generation or record modification is allowed; a student download renders only an already saved document.

## Isolation and revocation

- Student sessions use `northstar_student`, separate from the staff `northstar_session`. They can coexist in a browser without granting each other privileges. Student login cannot authorize `index.php`, the staff `document.php`, or `upgrade.php`.
- The portal derives the student ID from the active session/account; it never trusts a `student_id` supplied in a URL or form.
- Document downloads require both session student ID and institute ID; guessing another document number is denied, even for a student in the same institute. Payment PDFs are available only to their owner through the student endpoint, despite counsellor financial-download restrictions on the staff endpoint.
- Login and successful document downloads are recorded in `portal_events`. Staff enable/disable actions are in the normal audit log. There is not yet a student activity-log report UI or automated anomaly alerting.
- **Disable student access** revokes sessions and pending codes on subsequent requests. Re-enabling increments an access version, so a code issued before disabling cannot be used afterwards.
- Changing a student's email disables the account and revokes its sessions. Verify the new address and explicitly re-enable access. Records manually changed outside the app also fail access checks if the registered account email no longer matches the student record.
- Each portal account reserves a **unique normalized email**, including while disabled. Shared-parent emails, multiple enrollments under one email, account merging and self-service email changes are not supported in this phase. Re-enabling after a legitimate email correction updates the same student's reserved address; do not recycle identities casually.
- Students use OTP even if a server operator has explicitly enabled legacy password login for staff. Staff and student OTPs live in separate tables and have different audiences; they cannot be interchanged.

## Verification and operations

Run all tests after `composer install` (or using the dependency-included package):

```sh
python3 tests/smoke.py
python3 tests/communications.py
python3 tests/setup.py
python3 tests/portal.py
python3 tests/operations.py
python3 tests/services.py
python3 tests/applications.py
python3 tests/automation.py
python3 tests/student-accounts.py
```

Portal coverage includes upgrading a pre-portal database, no automatic provisioning, scoped staff controls, OTP expiry/attempts/session binding/audience separation, own-only reads/PDFs, URL tampering, financial mutation denial, logout, duplicate emails, revocation on disable/re-enable/email change, and staff/student cookie separation.

This phase was tested with PHP 8.5 WebAssembly, SQLite and private `.eml` capture. Native XAMPP/MySQL, browser rendering and real Gmail delivery still need verification on your server. Configure HTTPS/secure cookies for remote use; protect database/config/session files, keep dependencies patched, and apply privacy/consent/retention rules appropriate for student financial documents. Email OTP is not phishing-resistant MFA.
